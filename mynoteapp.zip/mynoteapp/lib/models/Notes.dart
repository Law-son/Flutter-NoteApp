// ignore_for_file: file_names

class Notes{
  String title;
  String description;

  Notes(this.title,this.description);
}
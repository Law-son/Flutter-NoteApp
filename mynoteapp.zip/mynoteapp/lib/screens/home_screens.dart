import 'package:flutter/material.dart';
import 'package:mynoteapp/models/Notes.dart';
import 'package:mynoteapp/models/NotesProvider.dart';
import 'package:provider/provider.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 0, 43, 107),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text(
          'Note App',
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 25),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Consumer<NotesProviders>(
          builder: (context, NotesProviders data, child) {
            return data.getNotes.isNotEmpty
                ? ListView.builder(
                    //shrinkWrap: true,
                    itemCount: data.getNotes.length,
                    itemBuilder: (context, index) {
                      return CardList(data.getNotes[index], index);
                    },
                  )
                : GestureDetector(
                    onTap: () {
                      // showAlertDialog(context);
                    },
                    child: const Center(
                        child: Text(
                      "ADD SOME NOTES",
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    )));
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.white,
        onPressed: () => _dialogBuilder(context),
        child: const Icon(Icons.add),
      ),
    );
  }
}

// ignore: must_be_immutable
class CardList extends StatefulWidget {
  final Notes notes;
  int index;
  CardList(this.notes, this.index, {super.key});

  @override
  State<CardList> createState() => _CardListState();
}

class _CardListState extends State<CardList> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: Slidable(
        key: const ValueKey(0),
        startActionPane: ActionPane(
            motion: const ScrollMotion(),
            dismissible: DismissiblePane(onDismissed: () {
              // Provider.of<NotesProviders>(context, listen: true)
              //     .removeNotes(widget.index);
            }),
            children: <Widget>[
              SlidableAction(
                  label: 'Delete',
                  backgroundColor: Colors.red,
                  icon: Icons.delete,
                  onPressed: (context) {
                    Provider.of<NotesProviders>(context, listen: false)
                        .removeNotes(widget.index);
                  }),
            ]),
        child: Container(
          decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(10),
                topLeft: Radius.circular(10),
              )),
          child: ListTile(
            leading: const Icon(Icons.note),
            title: Text(
              widget.notes.title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            subtitle: Text(
              widget.notes.description,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 17,
              ),
            ),
            trailing: const Icon(
              Icons.arrow_forward_ios,
              color: Colors.black26,
            ),
          ),
        ),
      ),
    );
  }
}

Future<void> _dialogBuilder(BuildContext context) {
  return showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      TextEditingController title = TextEditingController();
      TextEditingController description = TextEditingController();
      return AlertDialog(
        title: const Text('Add New Note'),
        content: SizedBox(
          width: 200,
          height: 100,
          child: Column(
            children: [
              TextFormField(
                controller: title,
                decoration: const InputDecoration(hintText: 'Note title'),
              ),
              TextFormField(
                controller: description,
                decoration: const InputDecoration(hintText: 'Note body'),
              ),
            ],
          ),
        ),
        actions: <Widget>[
          ElevatedButton(
              onPressed: () {
                Provider.of<NotesProviders>(context, listen: false)
                    .addNotes(title.text, description.text);
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 0, 43, 107),
              ),
              child: const Text(
                'Add Note',
                style: TextStyle(
                  color: Colors.white,
                ),
              )),
        ],
      );
    },
  );
}

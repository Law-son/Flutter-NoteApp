package com.example.mynoteapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
